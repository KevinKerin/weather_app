package com.example.weather_app

data class Item (val imageResource: Int, val text1: String, val text2: String)